<?php

namespace FlightBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FlightBundle extends Bundle
{
}
